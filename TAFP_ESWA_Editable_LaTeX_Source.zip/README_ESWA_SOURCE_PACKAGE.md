# TAFP-GraphRAG ESWA editable LaTeX source package

Target journal: Expert Systems with Applications
Package date: 20260818

This source package contains the editable LaTeX files used to build the ESWA submission manuscript.

Contents:
- manuscript.tex
- references.bib
- manuscript.bbl
- elsarticle.cls
- elsarticle-num.bst
- Figure_01.pdf through Figure_07.pdf
- README_ESWA_SOURCE_PACKAGE.md
- SHA256SUMS.txt

Compile order used for QA:
1. pdflatex manuscript.tex
2. bibtex8 manuscript
3. pdflatex manuscript.tex
4. pdflatex manuscript.tex

The ESWA submission update changes only target-journal frontmatter, metadata, and the public submission-support repository URL. It does not intentionally change the scientific results, tables, figures, references, methods, or result sections.
