# TAFP-GraphRAG Canonical Supplementary Tables

This package contains the canonical supplementary tables cited by the minor-revision manuscript.

- Included: Tables S1-S18 and S20-S29.
- Table S19 is intentionally absent; the canonical manuscript does not cite or distribute a Table S19.
- Where a supplementary result has an associated paired-test file, both files are included. `MANIFEST.json` identifies the primary file for each table number.
- All CSV files were copied byte-for-byte from the locked evidence sources or the current authoritative S27-S29 artifacts.
- SHA-256, row count, column count, missing-value count, and duplicate-row count are recorded in `MANIFEST.json`.

No values were recomputed or edited during packaging.
